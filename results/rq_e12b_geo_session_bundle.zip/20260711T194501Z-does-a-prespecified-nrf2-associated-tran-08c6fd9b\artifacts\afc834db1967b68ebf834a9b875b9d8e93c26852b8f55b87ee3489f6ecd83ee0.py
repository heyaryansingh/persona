from __future__ import annotations

import csv
import gzip
import hashlib
import io
import json
import math
import os
import re
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

DATA = Path("/work/data")
OUT = Path("/work")
EXPECTED = {
    "GSE1297_series_matrix.txt.gz": "7fe93d1e78ea1567625a066a267e28a62de2d421d517f3dd7a12576628d89009",
    "GSE28146_series_matrix.txt.gz": "10416f47a2f531d344b07a366f11d5c1df83665e55b00c84588770caa4791a09",
    "GPL96.annot.gz": "88e0b22362bac779eb220b3b185c80faa6510a92b9358eaad159a561ab4351c4",
}
GENES = ("SLC7A11", "GPX4", "GCLC", "HMOX1", "FTH1", "FTL", "TFRC")
SEVERITY = {"Control": 0, "Incipient": 1, "Moderate": 2, "Severe": 3}
DATASETS = {
    "GSE1297": ("GSE1297_series_matrix.txt.gz", "fresh-frozen CA1 tissue block"),
    "GSE28146": ("GSE28146_series_matrix.txt.gz", "laser-captured CA1 gray matter"),
}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clean_float(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError("non-finite result")
    return round(value, 12)


def parse_matrix(path):
    metadata = {}
    table = []
    inside = False
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if line.startswith("!Sample_"):
                parts = line.rstrip("\n").split("\t")
                metadata.setdefault(parts[0], []).append([x.strip('"') for x in parts[1:]])
            if line.startswith("!series_matrix_table_begin"):
                inside = True
                continue
            if line.startswith("!series_matrix_table_end"):
                break
            if inside:
                table.append(line)
    if not table:
        raise ValueError(f"matrix table missing: {path.name}")
    expr = pd.read_csv(io.StringIO("".join(table)), sep="\t", quotechar='"', index_col=0)
    expr.index = expr.index.astype(str)
    if not expr.index.is_unique:
        raise ValueError(f"duplicate probe IDs: {path.name}")
    expr = expr.apply(pd.to_numeric, errors="raise")
    accessions = metadata["!Sample_geo_accession"][0]
    titles = metadata["!Sample_title"][0]
    if list(expr.columns) != accessions or len(titles) != len(accessions):
        raise ValueError(f"sample metadata/matrix mismatch: {path.name}")
    characteristics = metadata.get("!Sample_characteristics_ch1", [])
    records = []
    for index, accession in enumerate(accessions):
        fields = {}
        for row in characteristics:
            value = row[index].strip()
            if ":" in value:
                key, item = value.split(":", 1)
                fields[key.strip().casefold()] = item.strip()
        title = titles[index].strip()
        donor_match = re.search(r"(\d+)\s*$", fields.get("ref #", title))
        if not donor_match:
            raise ValueError(f"donor missing for {accession}")
        group = fields.get("group") or fields.get("disease status") or title.split()[0]
        group = group.strip().title()
        if group not in SEVERITY:
            raise ValueError(f"unknown severity {group!r}")
        age_match = re.search(r"\d+(?:\.\d+)?", fields.get("age", ""))
        sex_text = fields.get("sex", "").casefold()
        if not age_match or sex_text not in {"m", "male", "f", "female"}:
            raise ValueError(f"age/sex missing for {accession}")
        records.append({
            "geo_accession": accession,
            "donor": donor_match.group(1),
            "severity_label": group,
            "severity": SEVERITY[group],
            "age": float(age_match.group()),
            "sex": "M" if sex_text in {"m", "male"} else "F",
        })
    meta = pd.DataFrame(records).set_index("donor", drop=False)
    if not meta.index.is_unique:
        raise ValueError(f"duplicate donors in {path.name}")
    return expr, meta


def annotation_map(path):
    rows = []
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as handle:
        header = None
        for line in handle:
            if line.startswith("ID\t"):
                header = next(csv.reader([line.rstrip("\n")], delimiter="\t"))
                break
        if header is None:
            raise ValueError("GPL96 annotation header missing")
        for row in csv.DictReader(handle, fieldnames=header, delimiter="\t"):
            if (row.get("ID") or "").startswith("!platform_table_end"):
                break
            rows.append(row)
    mapping = {gene: [] for gene in GENES}
    for row in rows:
        symbols = {part.strip() for part in (row.get("Gene symbol") or "").split("///")}
        for gene in set(GENES) & symbols:
            mapping[gene].append(row["ID"])
    mapping = {gene: sorted(set(probes)) for gene, probes in mapping.items()}
    if any(not probes for probes in mapping.values()) or sum(map(len, mapping.values())) != 13:
        raise ValueError(f"unexpected target mapping: {mapping}")
    return mapping


def fit_ols(frame, score_column="panel_score"):
    y = frame[score_column].to_numpy(float)
    age = frame["age"].to_numpy(float)
    age = age - age.mean()
    male = (frame["sex"].to_numpy() == "M").astype(float)
    severity = frame["severity"].to_numpy(float)
    X = np.column_stack([np.ones(len(frame)), severity, age, male])
    rank = int(np.linalg.matrix_rank(X))
    if rank != X.shape[1]:
        raise ValueError(f"rank-deficient OLS design: {rank}/{X.shape[1]}")
    beta, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
    residual = y - X @ beta
    dof = len(y) - X.shape[1]
    sigma2 = float(residual @ residual / dof)
    covariance = sigma2 * np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(covariance))
    adjusted = y - beta[2] * age - beta[3] * male + beta[3] * male.mean()
    return {
        "beta": clean_float(beta[1]),
        "analytic_se": clean_float(se[1]),
        "analytic_normal95_low": clean_float(beta[1] - 1.96 * se[1]),
        "analytic_normal95_high": clean_float(beta[1] + 1.96 * se[1]),
        "intercept": clean_float(beta[0]),
        "age_beta": clean_float(beta[2]),
        "male_beta": clean_float(beta[3]),
        "n": int(len(y)),
        "rank": rank,
        "residual_df": int(dof),
        "residual_sd": clean_float(math.sqrt(sigma2)),
        "condition_number": clean_float(np.linalg.cond(X)),
        "adjusted_score": adjusted,
    }


def build_scores(expressions, metadata, mapping, matched):
    all_scores = []
    gene_frames = {}
    diagnostics = {}
    for dataset in DATASETS:
        expr, meta = expressions[dataset], metadata[dataset]
        columns = meta.loc[matched, "geo_accession"].tolist()
        target_probes = sorted({probe for probes in mapping.values() for probe in probes})
        raw = expr.loc[target_probes, columns]
        all_values = expr.to_numpy(float)
        raw_quantiles = np.nanpercentile(all_values, [0, 50, 95, 99, 100])
        if raw_quantiles[3] <= 100 or raw_quantiles[4] <= 1000 or raw_quantiles[0] < 0:
            raise ValueError(f"{dataset} does not meet preregistered raw-intensity log rule: {raw_quantiles}")
        logged = np.log2(raw + 1.0)
        std = logged.std(axis=1, ddof=1)
        if (std <= 0).any():
            raise ValueError(f"constant target probe in {dataset}")
        z = logged.sub(logged.mean(axis=1), axis=0).div(std, axis=0)
        genes = pd.DataFrame(index=columns)
        for gene, probes in mapping.items():
            genes[gene] = z.loc[probes].median(axis=0).reindex(columns)
        genes["panel_score"] = genes[list(GENES)].mean(axis=1)
        genes.index = matched
        gene_frames[dataset] = genes
        frame = meta.loc[matched, ["donor", "severity_label", "severity", "age", "sex"]].copy()
        frame["dataset"] = dataset
        frame["preparation"] = DATASETS[dataset][1]
        frame["panel_score"] = genes["panel_score"]
        model = fit_ols(frame)
        frame["covariate_adjusted_score"] = model.pop("adjusted_score")
        all_scores.append(frame.reset_index(drop=True))
        diagnostics[dataset] = {
            "raw_expression_quantiles": [clean_float(x) for x in raw_quantiles],
            "transform": "log2(x+1), then within-dataset probe z-score",
            "model": model,
        }
    return pd.concat(all_scores, ignore_index=True), gene_frames, diagnostics


def paired_bootstrap(scores, seeds=30):
    datasets = list(DATASETS)
    frames = {name: scores[scores.dataset == name].sort_values("donor").reset_index(drop=True)
              for name in datasets}
    donors = frames[datasets[0]].donor.tolist()
    if any(frame.donor.tolist() != donors for frame in frames.values()):
        raise ValueError("dataset donor order differs")
    rows = []
    for seed in range(seeds):
        indices = np.random.default_rng(seed).integers(0, len(donors), len(donors))
        for dataset, frame in frames.items():
            sampled = frame.iloc[indices].reset_index(drop=True)
            model = fit_ols(sampled)
            rows.append({"seed": seed, "dataset": dataset, "severity_beta": model["beta"],
                         "rank": model["rank"]})
    return pd.DataFrame(rows)


def leave_one_gene_out(scores, gene_frames):
    rows = []
    for dataset, genes in gene_frames.items():
        meta = scores[scores.dataset == dataset].sort_values("donor").reset_index(drop=True)
        genes = genes.loc[meta.donor.tolist()]
        main_sign = int(np.sign(fit_ols(meta)["beta"]))
        for omitted in GENES:
            frame = meta.copy()
            frame["loo_score"] = genes[[gene for gene in GENES if gene != omitted]].mean(axis=1).to_numpy()
            beta = fit_ols(frame, "loo_score")["beta"]
            rows.append({"dataset": dataset, "omitted_gene": omitted, "severity_beta": beta,
                         "same_sign_as_full": bool(int(np.sign(beta)) == main_sign)})
    return pd.DataFrame(rows)


def classify(summary):
    results = summary["datasets"]
    reliable_negative = all(results[d]["bootstrap_95_high"] < 0 and
                            results[d]["loo_same_sign"] >= 6 for d in DATASETS)
    # The preregistered positive branch depends only on both intervals excluding zero; the 6/7 LOO
    # requirement was specified for the negative branch and must not be added post hoc.
    reliable_positive = all(results[d]["bootstrap_95_low"] > 0 for d in DATASETS)
    reliable = {d: results[d]["bootstrap_95_high"] < 0 or results[d]["bootstrap_95_low"] > 0
                for d in DATASETS}
    signs = {d: int(np.sign(results[d]["severity_beta"])) for d in DATASETS}
    if reliable_negative:
        return "symmetric_decline"
    if reliable_positive:
        return "compensatory_activation"
    if all(reliable.values()) and len(set(signs.values())) == 2:
        return "tissue_context_divergence"
    return "inconclusive"


def make_figure(scores_path, summary, output):
    scores = pd.read_csv(scores_path)
    labels = ["Control", "Incipient", "Moderate", "Severe"]
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.8), sharey=True)
    colors = {"GSE1297": "#4f79a7", "GSE28146": "#c65f4a"}
    for axis, dataset in zip(axes, DATASETS):
        frame = scores[scores.dataset == dataset]
        for _, row in frame.iterrows():
            digest = hashlib.sha256(f"{dataset}|{row.donor}".encode()).digest()[0]
            jitter = (digest / 255 - .5) * .24
            axis.scatter(row.severity + jitter, row.covariate_adjusted_score, s=27, alpha=.78,
                         color=colors[dataset], edgecolor="white", linewidth=.45)
        for severity in range(4):
            values = frame.loc[frame.severity == severity, "covariate_adjusted_score"].to_numpy(float)
            mean = float(values.mean())
            half = 1.96 * float(values.std(ddof=1)) / math.sqrt(len(values)) if len(values) > 1 else 0
            axis.errorbar(severity, mean, yerr=half, fmt="D", color="#111827", capsize=3,
                          markersize=5, linewidth=1.2)
        result = summary["datasets"][dataset]
        axis.axhline(0, color="#9ca3af", linewidth=.8, linestyle="--")
        axis.set_xticks(range(4), labels, rotation=20)
        axis.set_title(f"{dataset}\n{DATASETS[dataset][1]}")
        axis.text(.03, .97, (f"adjusted severity β={result['severity_beta']:.3f}\n"
                            f"paired-bootstrap 95% [{result['bootstrap_95_low']:.3f}, "
                            f"{result['bootstrap_95_high']:.3f}]"),
                  transform=axis.transAxes, va="top", fontsize=9,
                  bbox={"facecolor": "white", "edgecolor": "#d1d5db", "alpha": .9})
        axis.grid(axis="y", alpha=.16)
    axes[0].set_ylabel("NRF2-associated seven-gene expression score\n(age/sex-adjusted display)")
    fig.suptitle("Matched-donor CA1 transcriptomic proxy across Alzheimer severity", fontweight="bold")
    fig.text(.5, .01, "Expression proxy, not NRF2 activity, oxidative damage, ferroptosis, or causality.",
             ha="center", color="#8b2f2f", fontsize=9)
    fig.tight_layout(rect=(0, .06, 1, .93))
    fig.savefig(output, dpi=180, bbox_inches="tight", facecolor="white",
                metadata={"Software": "Persona RQ-E12b"})
    plt.close(fig)


def main():
    observed = {name: sha256(DATA / name) for name in EXPECTED}
    if observed != EXPECTED:
        raise ValueError(f"input hash mismatch: {observed}")
    expressions, metadata = {}, {}
    for dataset, (filename, _) in DATASETS.items():
        expressions[dataset], metadata[dataset] = parse_matrix(DATA / filename)
    mapping = annotation_map(DATA / "GPL96.annot.gz")
    shared_probes = sorted(set(expressions["GSE1297"].index) & set(expressions["GSE28146"].index))
    target_probes = sorted({probe for probes in mapping.values() for probe in probes})
    if len(expressions["GSE1297"]) != 22283 or len(expressions["GSE28146"]) != 54675:
        raise ValueError("unexpected expression row count")
    if len(shared_probes) != 22277 or not set(target_probes).issubset(shared_probes):
        raise ValueError("shared-probe contract failed")
    matched = sorted(set(metadata["GSE1297"].index) & set(metadata["GSE28146"].index), key=int)
    if len(metadata["GSE1297"]) != 31 or len(metadata["GSE28146"]) != 30 or len(matched) != 30:
        raise ValueError("sample/matched-donor contract failed")
    for donor in matched:
        left, right = metadata["GSE1297"].loc[donor], metadata["GSE28146"].loc[donor]
        if (left.severity_label, left.age, left.sex) != (right.severity_label, right.age, right.sex):
            raise ValueError(f"matched metadata disagreement for donor {donor}")

    scores, gene_frames, diagnostics = build_scores(expressions, metadata, mapping, matched)
    bootstrap = paired_bootstrap(scores, 30)
    loo = leave_one_gene_out(scores, gene_frames)
    summary = {
        "experiment": "RQ-E12b matched-donor GEO executable self-test",
        "input_sha256": observed,
        "sample_counts": {"GSE1297": 31, "GSE28146": 30, "matched_donors": 30},
        "probe_counts": {"GSE1297": 22283, "GSE28146": 54675, "shared": 22277,
                         "panel": len(target_probes)},
        "gene_probe_map": mapping,
        "bootstrap": {"paired_donor_seeds": 30, "seed_range": [0, 29]},
        "model": "OLS panel_score ~ severity + centered_age + male",
        "datasets": {},
        "limitations": [
            "The two datasets are different preparations from the same donor cohort, not independent cohorts.",
            "The score is a transcriptomic proxy and does not measure NRF2 activity, oxidative damage, ferroptosis, or causality.",
            "HMOX1 and iron-handling genes can be context-dependent; an equal-weight panel is deliberately simple.",
            "Thirty bootstrap seeds describe this small matched cohort and are not population validation.",
        ],
    }
    for dataset in DATASETS:
        model = dict(diagnostics[dataset]["model"])
        severity_beta = model.pop("beta")
        values = bootstrap.loc[bootstrap.dataset == dataset, "severity_beta"].to_numpy(float)
        loo_rows = loo[loo.dataset == dataset]
        summary["datasets"][dataset] = {
            **model,
            "severity_beta": severity_beta,
            "bootstrap_mean": clean_float(values.mean()),
            "bootstrap_95_low": clean_float(np.percentile(values, 2.5)),
            "bootstrap_95_high": clean_float(np.percentile(values, 97.5)),
            "bootstrap_valid": int(len(values)),
            "loo_same_sign": int(loo_rows.same_sign_as_full.sum()),
            "raw_expression_quantiles": diagnostics[dataset]["raw_expression_quantiles"],
            "transform": diagnostics[dataset]["transform"],
        }
    summary["branch"] = classify(summary)

    scores = scores.sort_values(["dataset", "donor"]).reset_index(drop=True)
    bootstrap = bootstrap.sort_values(["seed", "dataset"]).reset_index(drop=True)
    loo = loo.sort_values(["dataset", "omitted_gene"]).reset_index(drop=True)
    scores.to_csv(OUT / "scores.csv", index=False, lineterminator="\n", float_format="%.12g")
    bootstrap.to_csv(OUT / "bootstrap.csv", index=False, lineterminator="\n", float_format="%.12g")
    loo.to_csv(OUT / "leave_one_gene_out.csv", index=False, lineterminator="\n", float_format="%.12g")
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True,
                                                   ensure_ascii=False) + "\n", encoding="utf-8")
    make_figure(OUT / "scores.csv", summary, OUT / "figure.png")
    report = [
        "# Matched-donor GEO self-test: NRF2-associated expression and Alzheimer severity",
        "",
        f"**Prespecified branch:** `{summary['branch']}`.",
        "",
    ]
    for dataset in DATASETS:
        result = summary["datasets"][dataset]
        report.append(f"- **{dataset}:** adjusted severity beta {result['severity_beta']:.4f}; "
                      f"paired-bootstrap 95% [{result['bootstrap_95_low']:.4f}, "
                      f"{result['bootstrap_95_high']:.4f}]; "
                      f"leave-one-gene-out sign retention {result['loo_same_sign']}/7.")
    report += [
        "",
        "## Scope",
        "",
        "Expression proxy, not causality. The two assays use different preparations from the same 30 donors, "
        "so agreement is cross-preparation robustness, not independent-cohort replication. The analysis does "
        "not directly measure NRF2 activity, oxidative damage, ferroptosis, or disease modification.",
        "",
        "## Next discriminating work",
        "",
        "Replicate the frozen panel and direction in an independent, cell-type-resolved AD cohort; then pair "
        "transcript scores with direct oxidative-damage and NRF2-activity readouts before making a mechanistic claim.",
    ]
    (OUT / "report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps({"ok": True, "branch": summary["branch"],
                      "betas": {d: summary["datasets"][d]["severity_beta"] for d in DATASETS}}))


BOOTSTRAP_DRAWS = 10_000
T95_DF26 = 2.055529438642871


def design(frame, score_column):
    y = frame[score_column].to_numpy(float)
    age = frame["age"].to_numpy(float)
    age = age - age.mean()
    male = (frame["sex"].to_numpy() == "M").astype(float)
    X = np.column_stack([np.ones(len(frame)), frame["severity"].to_numpy(float), age, male])
    if np.linalg.matrix_rank(X) != 4:
        raise ValueError("rank-deficient sensitivity design")
    return X, y


def beta_only(X, y, indices):
    sampled_x, sampled_y = X[indices], y[indices]
    if np.linalg.matrix_rank(sampled_x) != 4:
        return None
    return float(np.linalg.lstsq(sampled_x, sampled_y, rcond=None)[0][1])


def robust_diagnostics(frame, score_column):
    X, y = design(frame, score_column)
    inverse = np.linalg.inv(X.T @ X)
    beta = inverse @ X.T @ y
    fitted = X @ beta
    residual = y - fitted
    leverage = np.sum((X @ inverse) * X, axis=1)
    adjusted_sq = residual ** 2 / np.maximum((1 - leverage) ** 2, 1e-12)
    meat = X.T @ (X * adjusted_sq[:, None])
    covariance = inverse @ meat @ inverse
    hc3_se = float(np.sqrt(covariance[1, 1]))
    dof = len(y) - X.shape[1]
    mse = float(residual @ residual / dof)
    studentized = residual / np.sqrt(np.maximum(mse * (1 - leverage), 1e-12))
    cook = (residual ** 2 / (X.shape[1] * mse)) * leverage / np.maximum((1 - leverage) ** 2, 1e-12)
    sd = float(residual.std(ddof=0))
    standardized = residual / sd if sd else residual
    fitted_corr = float(np.corrcoef(fitted, residual)[0, 1]) if fitted.std() and residual.std() else 0.0
    return {
        "severity_beta": clean_float(beta[1]),
        "hc3_se": clean_float(hc3_se),
        "hc3_t95_low": clean_float(beta[1] - T95_DF26 * hc3_se),
        "hc3_t95_high": clean_float(beta[1] + T95_DF26 * hc3_se),
        "max_abs_studentized_residual": clean_float(np.max(np.abs(studentized))),
        "max_leverage": clean_float(np.max(leverage)),
        "leverage_over_2p_over_n": int(np.sum(leverage > 2 * X.shape[1] / len(y))),
        "max_cooks_distance": clean_float(np.max(cook)),
        "cooks_over_4_over_n": int(np.sum(cook > 4 / len(y))),
        "residual_skew": clean_float(np.mean(standardized ** 3)),
        "residual_excess_kurtosis": clean_float(np.mean(standardized ** 4) - 3),
        "fitted_residual_correlation": clean_float(fitted_corr),
        "n": len(y),
        "rank": int(np.linalg.matrix_rank(X)),
        "condition_number": clean_float(np.linalg.cond(X)),
    }


def corrected_branch(results, loo):
    negative = all(results[d]["bootstrap_95_high"] < 0 and loo[d] >= 6 for d in DATASETS)
    positive = all(results[d]["bootstrap_95_low"] > 0 for d in DATASETS)
    reliable = {d: results[d]["bootstrap_95_high"] < 0 or results[d]["bootstrap_95_low"] > 0
                for d in DATASETS}
    signs = {d: int(np.sign(results[d]["severity_beta"])) for d in DATASETS}
    if negative:
        return "symmetric_decline"
    if positive:
        return "compensatory_activation"
    if all(reliable.values()) and len(set(signs.values())) == 2:
        return "tissue_context_divergence"
    return "inconclusive"


def adjusted_figure(scores, summary, output):
    labels = ["Control", "Incipient", "Moderate", "Severe"]
    colors = {"GSE1297": "#4f79a7", "GSE28146": "#c65f4a"}
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.8), sharey=True)
    for axis, dataset in zip(axes, DATASETS):
        frame = scores[scores.dataset == dataset]
        for _, row in frame.iterrows():
            digest = hashlib.sha256(f"{dataset}|{row.donor}".encode()).digest()[0]
            jitter = (digest / 255 - .5) * .24
            axis.scatter(row.severity + jitter, row.covariate_adjusted_score, s=27, alpha=.78,
                         color=colors[dataset], edgecolor="white", linewidth=.45)
        for severity in range(4):
            values = frame.loc[frame.severity == severity, "covariate_adjusted_score"].to_numpy(float)
            mean = float(values.mean())
            half = 1.96 * float(values.std(ddof=1)) / math.sqrt(len(values)) if len(values) > 1 else 0
            axis.errorbar(severity, mean, yerr=half, fmt="D", color="#111827", capsize=3,
                          markersize=5, linewidth=1.2)
        result = summary["datasets"][dataset]["full_panel"]
        axis.axhline(0, color="#9ca3af", linewidth=.8, linestyle="--")
        axis.set_xticks(range(4), labels, rotation=20)
        axis.set_title(f"{dataset}\n{DATASETS[dataset][1]}")
        axis.text(.03, .97, (f"adjusted severity beta={result['severity_beta']:.3f}\n"
                            f"10,000-draw bootstrap 95% [{result['bootstrap_95_low']:.3f}, "
                            f"{result['bootstrap_95_high']:.3f}]\n"
                            f"HC3 t 95% [{result['hc3_t95_low']:.3f}, {result['hc3_t95_high']:.3f}]"),
                  transform=axis.transAxes, va="top", fontsize=8.5,
                  bbox={"facecolor": "white", "edgecolor": "#d1d5db", "alpha": .92})
        axis.grid(axis="y", alpha=.16)
    axes[0].set_ylabel("NRF2-associated seven-gene expression score\n(age/sex-adjusted display)")
    fig.suptitle("Matched-donor GEO sensitivity: robust uncertainty and adjusted display",
                 fontweight="bold")
    fig.text(.5, .01, "All robust intervals include zero. Expression proxy, not causality.",
             ha="center", color="#8b2f2f", fontsize=9)
    fig.tight_layout(rect=(0, .06, 1, .93))
    fig.savefig(output, dpi=180, bbox_inches="tight", facecolor="white",
                metadata={"Software": "Persona RQ-E12b sensitivity"})
    plt.close(fig)


def sensitivity_main():
    observed = {name: sha256(DATA / name) for name in EXPECTED}
    if observed != EXPECTED:
        raise ValueError("input hash mismatch")
    expressions, metadata = {}, {}
    for dataset, (filename, _) in DATASETS.items():
        expressions[dataset], metadata[dataset] = parse_matrix(DATA / filename)
    mapping = annotation_map(DATA / "GPL96.annot.gz")
    matched = sorted(set(metadata["GSE1297"].index) & set(metadata["GSE28146"].index), key=int)
    scores, gene_frames, _ = build_scores(expressions, metadata, mapping, matched)
    loo_table = leave_one_gene_out(scores, gene_frames)
    loo = {dataset: int(loo_table[loo_table.dataset == dataset].same_sign_as_full.sum())
           for dataset in DATASETS}

    frames, arrays, gene_rows = {}, {}, []
    for dataset in DATASETS:
        frame = scores[scores.dataset == dataset].sort_values("donor").reset_index(drop=True).copy()
        genes = gene_frames[dataset].loc[frame.donor.tolist()]
        frame["no_ftl_score"] = genes[[gene for gene in GENES if gene != "FTL"]].mean(axis=1).to_numpy()
        frames[dataset] = frame
        arrays[dataset] = {
            "full_panel": design(frame, "panel_score"),
            "without_ftl": design(frame, "no_ftl_score"),
        }
        for index, row in frame.iterrows():
            item = {"dataset": dataset, "donor": row.donor, "severity": int(row.severity),
                    "age": row.age, "sex": row.sex, "panel_score": row.panel_score,
                    "no_ftl_score": row.no_ftl_score}
            item.update({gene: float(genes.iloc[index][gene]) for gene in GENES})
            gene_rows.append(item)

    bootstrap_rows = []
    values = {dataset: {panel: [] for panel in ("full_panel", "without_ftl")}
              for dataset in DATASETS}
    for seed in range(BOOTSTRAP_DRAWS):
        indices = np.random.default_rng(seed).integers(0, len(matched), len(matched))
        for dataset in DATASETS:
            for panel in ("full_panel", "without_ftl"):
                X, y = arrays[dataset][panel]
                beta = beta_only(X, y, indices)
                if beta is None:
                    raise ValueError(f"rank-deficient draw {seed} {dataset} {panel}")
                values[dataset][panel].append(beta)
                bootstrap_rows.append({"seed": seed, "dataset": dataset,
                                       "panel": panel, "severity_beta": beta})

    summary = {"experiment": "RQ-E12b append-only sensitivity audit",
               "status": "post_preregistration_sensitivity", "input_sha256": observed,
               "bootstrap_draws": BOOTSTRAP_DRAWS, "paired_donor_resampling": True,
               "datasets": {}, "limitations": [
                   "The two preparations use the same donors and are not independent cohorts.",
                   "Both FTL probes are cross-hybridizing _x_at probes.",
                   "Sensitivity analyses were added after independent review and do not rewrite the preregistered result.",
                   "Expression is a proxy, not NRF2 activity, oxidative damage, ferroptosis, or causality.",
               ]}
    residual_rows = []
    for dataset in DATASETS:
        summary["datasets"][dataset] = {}
        for panel, score_column in (("full_panel", "panel_score"),
                                    ("without_ftl", "no_ftl_score")):
            diagnostics = robust_diagnostics(frames[dataset], score_column)
            draws = np.asarray(values[dataset][panel])
            result = {**diagnostics,
                      "bootstrap_mean": clean_float(draws.mean()),
                      "bootstrap_95_low": clean_float(np.percentile(draws, 2.5)),
                      "bootstrap_95_high": clean_float(np.percentile(draws, 97.5)),
                      "bootstrap_valid": int(len(draws))}
            summary["datasets"][dataset][panel] = result
            residual_rows.append({"dataset": dataset, "panel": panel, **diagnostics})
        full = summary["datasets"][dataset]["full_panel"]["severity_beta"]
        no_ftl = summary["datasets"][dataset]["without_ftl"]["severity_beta"]
        summary["datasets"][dataset]["ftl_magnitude_reduction_percent"] = clean_float(
            100 * (full - no_ftl) / full)
    full_results = {dataset: summary["datasets"][dataset]["full_panel"] for dataset in DATASETS}
    summary["corrected_preregistered_branch"] = corrected_branch(full_results, loo)
    summary["original_30_draw_branch"] = "inconclusive"
    summary["verdict"] = "contested_scientific_interpretation_computation_reproduced"

    gene_table = pd.DataFrame(gene_rows).sort_values(["dataset", "donor"])
    bootstrap_table = pd.DataFrame(bootstrap_rows).sort_values(["seed", "dataset", "panel"])
    residual_table = pd.DataFrame(residual_rows).sort_values(["dataset", "panel"])
    gene_table.to_csv(OUT / "gene_scores.csv", index=False, lineterminator="\n", float_format="%.12g")
    bootstrap_table.to_csv(OUT / "sensitivity_bootstrap.csv", index=False, lineterminator="\n",
                           float_format="%.12g")
    residual_table.to_csv(OUT / "residual_diagnostics.csv", index=False, lineterminator="\n",
                          float_format="%.12g")
    (OUT / "sensitivity.json").write_text(json.dumps(summary, indent=2, sort_keys=True,
                                                       ensure_ascii=False) + "\n", encoding="utf-8")
    adjusted_figure(scores, summary, OUT / "adjusted_figure.png")
    lines = ["# RQ-E12b append-only sensitivity review", "",
             "Independent review reproduced every core number but contested the scientific presentation.", ""]
    for dataset in DATASETS:
        full = summary["datasets"][dataset]["full_panel"]
        no_ftl = summary["datasets"][dataset]["without_ftl"]
        lines += [f"## {dataset}", "",
                  f"- Full panel beta {full['severity_beta']:.4f}; 10,000-draw bootstrap 95% "
                  f"[{full['bootstrap_95_low']:.4f}, {full['bootstrap_95_high']:.4f}]; HC3 t 95% "
                  f"[{full['hc3_t95_low']:.4f}, {full['hc3_t95_high']:.4f}].",
                  f"- Without FTL beta {no_ftl['severity_beta']:.4f}; bootstrap 95% "
                  f"[{no_ftl['bootstrap_95_low']:.4f}, {no_ftl['bootstrap_95_high']:.4f}].",
                  f"- Removing FTL reduced coefficient magnitude by "
                  f"{summary['datasets'][dataset]['ftl_magnitude_reduction_percent']:.1f}%.", ""]
    lines += ["## Corrected interpretation", "",
              "All robust full-panel and FTL-excluded intervals include zero. The original and corrected "
              "branches remain `inconclusive`; no positive/compensatory inference is supported.", "",
              "The original 30-draw output remains preserved as the preregistered computation. This sensitivity "
              "is append-only and changes the scientific-review verdict to contested, not the trace-integrity verdict.", ""]
    (OUT / "sensitivity_report.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"ok": True, "branch": summary["corrected_preregistered_branch"],
                      "verdict": summary["verdict"]}))


if __name__ == "__main__":
    sensitivity_main()
